import os, tempfile
os.environ.update(EMBEDDING_BACKEND="hash", CHROMA_PERSIST_DIR=tempfile.mkdtemp(), ADMIN_TOKEN="test-token-123", RATE_LIMIT_PER_MIN="1000")

from fastapi.testclient import TestClient
from app.main import app


def test_flow():
    with TestClient(app) as c:
        h = c.get("/api/health").json()
        assert h["status"] == "ok" and h["chunks_indexed"] > 0          # auto-seeded
        r = c.post("/api/chat", json={"query": "What is the last date to pay semester fees?"}).json()
        assert r["citations"] and r["citations"][0]["document"] == "fee_structure.txt", r
        r = c.post("/api/chat", json={"query": "zebra quantum banana"}).json()
        assert r["citations"] == []                                       # irrelevant -> no fabricated answer
        assert c.get("/api/admin/documents").status_code == 401
        H = {"X-Admin-Token": "test-token-123"}
        up = c.post("/api/admin/documents/upload", headers=H, files={"file": ("lib.txt", b"Library hours are 9am to 8pm on weekdays.")}, data={"category": "hostel"})
        assert up.status_code == 200, up.text
        assert c.post("/api/admin/documents/upload", headers=H, files={"file": ("x.exe", b"x")}).status_code == 400
        docs = c.get("/api/admin/documents", headers=H).json()
        assert any(d["filename"] == "lib.txt" for d in docs)
        assert c.delete(f"/api/admin/documents/{up.json()['document']['id']}", headers=H).status_code == 200
        assert "Semester 5" in c.get("/").text or "CollegeConnect" in c.get("/").text   # frontend served
