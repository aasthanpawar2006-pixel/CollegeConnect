"""
Loads the files in data/sample_docs/ straight into the vector store,
bypassing the HTTP API. Handy for local setup / demos.

Run from the backend/ directory:
    python scripts/load_sample_docs.py
"""
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from app.rag.ingest import ingest_file  # noqa: E402

SAMPLE_DIR = Path(__file__).resolve().parent.parent / "data" / "sample_docs"

if __name__ == "__main__":
    if not SAMPLE_DIR.exists():
        print(f"No sample_docs directory found at {SAMPLE_DIR}")
        raise SystemExit(1)

    for file_path in SAMPLE_DIR.glob("*"):
        if not file_path.is_file():
            continue
        raw_bytes = file_path.read_bytes()
        result = ingest_file(filename=file_path.name, raw_bytes=raw_bytes, category="sample")
        print(f"Indexed {result['chunks']} chunks from {result['filename']}")

    print("\nDone. Start the server with: uvicorn app.main:app --reload")
    print("Then try: POST /chat  {\"query\": \"What is the last date to pay fees?\"}")
