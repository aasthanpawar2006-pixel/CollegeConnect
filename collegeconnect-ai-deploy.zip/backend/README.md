# CollegeConnect AI — Backend

FastAPI + RAG backend for the CollegeConnect AI chatbot. Works out of the box
in **mock mode** (no API key needed) using extractive answers from your own
documents, and upgrades to Gemini or OpenAI the moment you add a key.

## Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

## Load sample documents and run

```bash
python scripts/load_sample_docs.py
uvicorn app.main:app --reload
```

Open http://localhost:8000/docs for interactive API docs.

## Try it

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the last date to pay semester fees?", "language": "en"}'
```

## Uploading your own documents (admin)

```bash
curl -X POST http://localhost:8000/admin/documents/upload \
  -H "X-Admin-Token: change-me-please" \
  -F "file=@/path/to/admission_brochure.pdf" \
  -F "category=admissions"
```

Set `ADMIN_TOKEN` in `.env` to something real before deploying.

## Switching on a real LLM

Edit `.env`:

```
AI_PROVIDER=gemini
GEMINI_API_KEY=your-key-here
```

or

```
AI_PROVIDER=openai
OPENAI_API_KEY=your-key-here
```

No code changes needed — `app/rag/llm.py` picks the provider at request time
and falls back to mock mode if the key is missing.

## Project layout

```
app/
  main.py             FastAPI app + CORS + router registration
  config.py            Settings loaded from .env
  models.py             Pydantic request/response schemas
  rag/
    ingest.py           File -> text -> chunks -> vector store
    retrieve.py          Vector search + citation formatting
    llm.py                Mock / Gemini / OpenAI answer generation
  routes/
    chat.py             POST /chat
    documents.py        Admin upload / list / delete (token-protected)
    health.py           GET /health
  db/
    vectorstore.py      ChromaDB persistence wrapper
data/sample_docs/        Sample admission, fee, and exam notices
scripts/load_sample_docs.py   One-off bulk loader for the samples
```

## Connecting the frontend

The demo landing page (`collegeconnect-ai.html`) currently uses scripted
mock answers in JavaScript. To wire it to this backend, replace the
`sendDemoMessage` function's canned lookup with a `fetch()` call to
`POST /chat`, using the response's `answer` and `citations` fields.
Remember to set `ALLOWED_ORIGINS` in `.env` to match wherever the frontend
is served from.

## Notes

- Embeddings run locally via `sentence-transformers` — no API key required
  just to index and search documents.
- Chunking is a simple character sliding window (`rag/ingest.py`). Fine for
  notices and brochures; consider a token-aware splitter for longer PDFs.
- ChromaDB persists to `./chroma_store` by default — safe to delete to reset.
