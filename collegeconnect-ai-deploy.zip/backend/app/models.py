from typing import Literal
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=1000, description="The user's question, in any supported language")
    language: Literal["en", "hi", "mr"] = "en"
    top_k: int = Field(4, ge=1, le=10, description="How many document chunks to retrieve")


class Citation(BaseModel):
    document: str
    page: int | None = None
    snippet: str


class ChatResponse(BaseModel):
    answer: str
    citations: list[Citation]
    mode: Literal["mock", "gemini", "openai"]


class DocumentInfo(BaseModel):
    id: str
    filename: str
    chunks: int
    category: str


class UploadResponse(BaseModel):
    document: DocumentInfo
    message: str
