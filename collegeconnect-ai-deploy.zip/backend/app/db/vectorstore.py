"""ChromaDB wrapper. Embeddings are computed locally (no API key needed to search)."""
import hashlib
import math
import re
import uuid

import chromadb
from chromadb.api.types import Documents, EmbeddingFunction, Embeddings

from app.config import settings

_collection = None
_DIM = 384


class HashEmbedding(EmbeddingFunction):
    """Deterministic, dependency-free bag-of-words embedding. Good for tests/offline use."""

    def __init__(self):
        pass

    @staticmethod
    def name() -> str:
        return "cc_hash_embedding"

    def get_config(self):
        return {}

    @staticmethod
    def build_from_config(config):
        return HashEmbedding()

    def __call__(self, input: Documents) -> Embeddings:
        out = []
        for text in input:
            vec = [0.0] * _DIM
            words = [w for w in re.findall(r"\w+", text.lower()) if len(w) > 2]
            for w in words:
                h = int(hashlib.md5(w.encode()).hexdigest(), 16)
                vec[h % _DIM] += 1.0 if (h >> 100) & 1 else -1.0
                vec[(h >> 20) % _DIM] += 0.5
            norm = math.sqrt(sum(v * v for v in vec)) or 1.0
            out.append([v / norm for v in vec])
        return out


def _embedding_fn():
    if settings.embedding_backend == "hash":
        return HashEmbedding()
    from chromadb.utils.embedding_functions import DefaultEmbeddingFunction
    return DefaultEmbeddingFunction()


def get_collection():
    global _collection
    if _collection is None:
        client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        # backend in the name so vectors from different embedders never mix
        _collection = client.get_or_create_collection(
            name=f"college_documents_{settings.embedding_backend}",
            embedding_function=_embedding_fn(),
            metadata={"hnsw:space": "cosine"},
        )
    return _collection


def add_chunks(document_id: str, filename: str, category: str, chunks: list[str]) -> int:
    col = get_collection()
    ids = [f"{document_id}-{i}" for i in range(len(chunks))]
    metas = [
        {"document_id": document_id, "filename": filename, "category": category, "chunk_index": i}
        for i in range(len(chunks))
    ]
    col.add(ids=ids, documents=chunks, metadatas=metas)
    return len(chunks)


def query(text: str, top_k: int = 4) -> list[dict]:
    col = get_collection()
    n = col.count()
    if n == 0:
        return []
    res = col.query(query_texts=[text], n_results=min(top_k, n))
    hits = [
        {"text": d, "metadata": m, "distance": dist}
        for d, m, dist in zip(res["documents"][0], res["metadatas"][0], res["distances"][0])
    ]
    return [h for h in hits if h["distance"] <= settings.max_distance]


def list_documents() -> list[dict]:
    col = get_collection()
    if col.count() == 0:
        return []
    by_doc: dict[str, dict] = {}
    for meta in col.get(include=["metadatas"])["metadatas"]:
        d = by_doc.setdefault(
            meta["document_id"],
            {"id": meta["document_id"], "filename": meta["filename"], "category": meta["category"], "chunks": 0},
        )
        d["chunks"] += 1
    return list(by_doc.values())


def delete_document(document_id: str) -> None:
    get_collection().delete(where={"document_id": document_id})


def new_document_id() -> str:
    return uuid.uuid4().hex[:12]
