from fastapi import APIRouter

from app.config import settings
from app.db.vectorstore import get_collection

router = APIRouter(tags=["health"])


@router.get("/health")
def health():
    return {
        "status": "ok",
        "app": settings.app_name,
        "ai_provider": settings.ai_provider,
        "chunks_indexed": get_collection().count(),
    }
