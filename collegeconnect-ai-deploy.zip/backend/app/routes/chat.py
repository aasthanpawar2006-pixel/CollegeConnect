import time
from collections import defaultdict, deque

from fastapi import APIRouter, HTTPException, Request

from app.config import settings
from app.models import ChatRequest, ChatResponse
from app.rag.llm import generate_answer
from app.rag.retrieve import build_context_block, hits_to_citations, retrieve

router = APIRouter(prefix="/chat", tags=["chat"])
_hits: dict[str, deque] = defaultdict(deque)


def _rate_limit(ip: str) -> None:
    limit = settings.rate_limit_per_min
    if limit <= 0:
        return
    now, q = time.monotonic(), _hits[ip]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(status_code=429, detail="Too many questions — please wait a minute.")
    q.append(now)


@router.post("", response_model=ChatResponse)
def chat(request: ChatRequest, http: Request) -> ChatResponse:
    _rate_limit(http.client.host if http.client else "unknown")
    hits = retrieve(request.query, top_k=request.top_k)
    answer, mode = generate_answer(request.query, hits, build_context_block(hits), request.language)
    return ChatResponse(answer=answer, citations=hits_to_citations(hits), mode=mode)
