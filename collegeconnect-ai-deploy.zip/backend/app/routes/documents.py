import secrets
from pathlib import Path

from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Header

from app.config import settings
from app.models import UploadResponse, DocumentInfo
from app.rag.ingest import ingest_file
from app.db.vectorstore import list_documents, delete_document

router = APIRouter(prefix="/admin/documents", tags=["admin"])


ALLOWED_EXT = {".pdf", ".txt", ".md"}


def require_admin(x_admin_token: str = Header(default="")):
    if len(settings.admin_token) < 8 or settings.admin_token == "change-me-please":
        raise HTTPException(status_code=503, detail="Admin disabled: set a strong ADMIN_TOKEN (8+ chars) on the server")
    if not secrets.compare_digest(x_admin_token, settings.admin_token):
        raise HTTPException(status_code=401, detail="Invalid or missing admin token")


@router.get("", response_model=list[DocumentInfo])
def get_documents(x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    return list_documents()


@router.post("/upload", response_model=UploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    category: str = Form("general"),
    x_admin_token: str = Header(default=""),
):
    require_admin(x_admin_token)
    name = Path(file.filename or "").name
    if Path(name).suffix.lower() not in ALLOWED_EXT:
        raise HTTPException(status_code=400, detail="Only .pdf, .txt and .md files are supported")
    raw_bytes = await file.read()
    if len(raw_bytes) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"File larger than {settings.max_upload_mb} MB")
    try:
        result = ingest_file(filename=name, raw_bytes=raw_bytes, category=category)
    except Exception as e:  # unreadable/corrupt PDF, empty text, ...
        raise HTTPException(status_code=400, detail=str(e))

    return UploadResponse(
        document=DocumentInfo(**result),
        message=f"Indexed {result['chunks']} chunks from {name}",
    )


@router.delete("/{document_id}")
def remove_document(document_id: str, x_admin_token: str = Header(default="")):
    require_admin(x_admin_token)
    delete_document(document_id)
    return {"message": f"Deleted document {document_id}"}
