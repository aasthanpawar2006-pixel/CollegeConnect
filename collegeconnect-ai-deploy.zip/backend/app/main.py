import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import APIRouter, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.db.vectorstore import get_collection
from app.rag.ingest import ingest_file
from app.routes import chat, documents, health

log = logging.getLogger("collegeconnect")
BASE = Path(__file__).resolve().parent.parent
SAMPLE_DIR = BASE / "data" / "sample_docs"
STATIC_DIR = BASE / "static"


def seed_samples() -> None:
    """Index the sample notices on first boot so the site answers real questions immediately."""
    if not settings.auto_seed or get_collection().count() > 0 or not SAMPLE_DIR.exists():
        return
    for f in sorted(SAMPLE_DIR.glob("*.txt")):
        r = ingest_file(f.name, f.read_bytes(), category="sample")
        log.info("Seeded %s (%d chunks)", r["filename"], r["chunks"])


@asynccontextmanager
async def lifespan(_: FastAPI):
    seed_samples()
    yield


app = FastAPI(title=settings.app_name, lifespan=lifespan)

if settings.origins_list:
    app.add_middleware(
        CORSMiddleware, allow_origins=settings.origins_list,
        allow_methods=["*"], allow_headers=["*"],
    )

api = APIRouter(prefix="/api")
api.include_router(health.router)
api.include_router(chat.router)
api.include_router(documents.router)
app.include_router(api)

# Frontend served from the same origin as the API -> no CORS, one deployment.
app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
