from app.db.vectorstore import query as vector_query
from app.models import Citation


def retrieve(user_query: str, top_k: int = 4) -> list[dict]:
    """Return raw chunk hits for a query, most relevant first."""
    return vector_query(user_query, top_k=top_k)


def hits_to_citations(hits: list[dict]) -> list[Citation]:
    citations = []
    for h in hits:
        meta = h["metadata"]
        snippet = h["text"][:220].strip()
        if len(h["text"]) > 220:
            snippet += "…"
        citations.append(
            Citation(document=meta["filename"], page=None, snippet=snippet)
        )
    return citations


def build_context_block(hits: list[dict]) -> str:
    """Format retrieved chunks into a context block for the LLM prompt."""
    parts = []
    for i, h in enumerate(hits, start=1):
        parts.append(f"[{i}] Source: {h['metadata']['filename']}\n{h['text']}")
    return "\n\n".join(parts)
