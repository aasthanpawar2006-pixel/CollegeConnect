"""
Turns an uploaded file into chunks and stores them in the vector database.
Supports .txt, .md, and .pdf out of the box.
"""
from pypdf import PdfReader
import io

from app.db.vectorstore import add_chunks, new_document_id


def extract_text(filename: str, raw_bytes: bytes) -> str:
    lower = filename.lower()
    if lower.endswith(".pdf"):
        reader = PdfReader(io.BytesIO(raw_bytes))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    # txt / md / anything else: treat as plain text
    return raw_bytes.decode("utf-8", errors="ignore")


def chunk_text(text: str, chunk_size: int = 800, overlap: int = 120) -> list[str]:
    """
    Simple sliding-window chunker on characters. Good enough for notices,
    brochures, and fee circulars. Swap for a token-aware splitter if you
    move to longer, denser documents.
    """
    text = " ".join(text.split())  # normalize whitespace
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        if end >= len(text):
            break
        start = end - overlap
    return chunks


def ingest_file(filename: str, raw_bytes: bytes, category: str = "general") -> dict:
    text = extract_text(filename, raw_bytes)
    chunks = chunk_text(text)
    if not chunks:
        raise ValueError(f"No extractable text found in {filename}")

    document_id = new_document_id()
    count = add_chunks(document_id=document_id, filename=filename, category=category, chunks=chunks)
    return {"id": document_id, "filename": filename, "category": category, "chunks": count}
