"""
Answer generation. Providers: mock (extractive, no key) | gemini | openai.
Any provider error falls back to the extractive answer, so the site never breaks.
"""
import logging

import httpx

from app.config import settings

log = logging.getLogger("collegeconnect")
LANGS = {"en": "English", "hi": "Hindi", "mr": "Marathi"}

SYSTEM_PROMPT = """You are CollegeConnect AI, a virtual assistant for a college.
Answer the student's question using ONLY the information in the provided context.
Be concise and specific (dates, amounts, steps). If the context does not contain
the answer, say you don't have that information yet and suggest which office to
contact. Always answer in {language}."""

NO_INFO = {
    "en": "I couldn't find that in the college documents yet. Try asking about admissions, fees, exams or placements, or contact the college office.",
    "hi": "यह जानकारी अभी कॉलेज दस्तावेज़ों में नहीं मिली। कृपया प्रवेश, फीस, परीक्षा या प्लेसमेंट के बारे में पूछें या कॉलेज कार्यालय से संपर्क करें।",
    "mr": "ही माहिती अजून कॉलेज कागदपत्रांत सापडली नाही. कृपया प्रवेश, फी, परीक्षा किंवा प्लेसमेंटबद्दल विचारा किंवा कॉलेज कार्यालयाशी संपर्क साधा.",
}


def _mock_answer(hits: list[dict]) -> str:
    top = hits[0]
    text = top["text"].strip()
    return f"Based on {top['metadata']['filename']}: {text[:400]}" + ("…" if len(text) > 400 else "")


def _gemini(query: str, ctx: str, language: str) -> str:
    prompt = SYSTEM_PROMPT.format(language=language) + f"\n\nContext:\n{ctx}\n\nQuestion: {query}\n\nAnswer:"
    r = httpx.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/{settings.gemini_model}:generateContent",
        headers={"x-goog-api-key": settings.gemini_api_key},
        json={"contents": [{"parts": [{"text": prompt}]}]},
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["candidates"][0]["content"]["parts"][0]["text"].strip()


def _openai(query: str, ctx: str, language: str) -> str:
    r = httpx.post(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {settings.openai_api_key}"},
        json={
            "model": settings.openai_model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT.format(language=language)},
                {"role": "user", "content": f"Context:\n{ctx}\n\nQuestion: {query}"},
            ],
        },
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def generate_answer(user_query: str, hits: list[dict], context_block: str, language: str) -> tuple[str, str]:
    """Returns (answer_text, mode_used)."""
    if not hits:
        return NO_INFO.get(language, NO_INFO["en"]), "mock"

    provider = settings.ai_provider.lower()
    lang = LANGS.get(language, "English")
    try:
        if provider == "gemini" and settings.gemini_api_key:
            return _gemini(user_query, context_block, lang), "gemini"
        if provider == "openai" and settings.openai_api_key:
            return _openai(user_query, context_block, lang), "openai"
    except Exception as exc:  # network, quota, bad key...
        log.warning("LLM provider %s failed (%s); using extractive answer", provider, exc)
    return _mock_answer(hits), "mock"
