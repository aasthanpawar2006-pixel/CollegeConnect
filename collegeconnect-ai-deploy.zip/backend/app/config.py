"""Settings loaded from environment variables / .env. Works with zero config (mock mode)."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "CollegeConnect AI"

    # mock | gemini | openai
    ai_provider: str = "mock"
    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"

    # Only needed if the frontend is hosted on a DIFFERENT origin than the API.
    allowed_origins: str = ""

    chroma_persist_dir: str = "./chroma_store"
    # onnx = MiniLM via onnxruntime (default, no PyTorch) | hash = offline keyword-ish fallback
    embedding_backend: str = "onnx"
    max_distance: float = 0.8  # chunks farther than this (cosine) are treated as "not relevant"
    auto_seed: bool = True     # index data/sample_docs on first start if the store is empty

    admin_token: str = ""
    max_upload_mb: int = 10
    rate_limit_per_min: int = 20

    @property
    def origins_list(self) -> list[str]:
        return [o.strip() for o in self.allowed_origins.split(",") if o.strip()]


settings = Settings()
