# CollegeConnect AI

One deployable service: **FastAPI + RAG backend** that also serves the **multilingual (EN/HI/MR) website**.
Works with no API keys (answers are extracted from your documents); add a Gemini or OpenAI key for natural-language answers.

```
GET  /                         website
POST /api/chat                 {query, language: en|hi|mr, top_k}
GET  /api/health
GET/POST/DELETE /api/admin/documents   (header X-Admin-Token)
GET  /docs                     interactive API docs
```

## Run locally
```bash
cd backend
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # set ADMIN_TOKEN (8+ chars)
uvicorn app.main:app --reload
```
Open http://localhost:8000 — sample notices are indexed automatically on first start.
Tests: `pip install -r requirements-dev.txt && pytest`

## Deploy (pick one)
**Render (easiest):** push this folder to GitHub → Render → *New → Blueprint* → select repo. `ADMIN_TOKEN` is generated for you (Dashboard → Environment). The 1 GB disk keeps uploads across deploys. Free plan works for testing but has no disk and too little RAM to be reliable.

**Docker anywhere (Railway, Fly.io, VPS, Cloud Run):**
```bash
docker build -t collegeconnect-ai .
docker run -p 8000:8000 -v cc_data:/data -e ADMIN_TOKEN=choose-a-long-secret collegeconnect-ai
```
Mount a persistent volume at `/data`, otherwise uploaded documents disappear on redeploy. Put HTTPS in front (all the platforms above do it for you).

## Go live checklist
1. Set `ADMIN_TOKEN` (admin panel stays disabled until you do).
2. Open the site → **Admin login** → delete the sample documents, upload your real PDFs/notices.
3. Optional: `AI_PROVIDER=gemini` + `GEMINI_API_KEY` (or `openai` + `OPENAI_API_KEY`). If the provider errors, the app falls back to extractive answers automatically.
4. Chat is rate-limited to 20 questions/min per IP (`RATE_LIMIT_PER_MIN`), which protects your API bill.

## Known limits
- The default embedding model is English-centric: Hindi/Marathi *questions* work best when your documents are also in that language, or with an LLM provider enabled for the answer.
- Scanned (image-only) PDFs have no text layer and can't be indexed; run OCR first.
- The "Dashboards" section of the landing page is a static illustration with sample numbers.
